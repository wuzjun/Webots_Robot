#ifndef __CHIASSIS_H
#define __CHIASSIS_H

#include <stdio.h>
#include <stdint.h>
#include <Math.h>

void RubberWheel_Solve(float *VOMEGA, float *Position, float *Last_Position, int key);

#endif /* __CHIASSIS_H */


