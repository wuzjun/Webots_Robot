#ifndef __KEY_H
#define __KEY_H

#include <stdio.h>
#include <stdint.h>
#include <Math.h>
#include <webots/keyboard.h>


void get_Keyboard_Control(float *VX, float *VOMEGA, int *key);


#endif /*__KEY_H*/